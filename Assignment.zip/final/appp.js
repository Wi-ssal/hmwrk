const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

// Pre-registered users
const users = {
    client: { password: 'clientpass', email: 'client@lab.com', secret2FA: '' },
    victim: { password: 'victimpass', email: 'hidden', secret2FA: '' }
};

// Simulated inbox per email
const inbox = {
    'client@lab.com': []
};

// Generate random 2-digit code
function generateCode() {
    return Math.floor(10 + Math.random() * 9).toString();
}



// Middleware setup
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'supersecret', resave: false, saveUninitialized: true }));

// Home page
app.get('/', (req, res) => {
    res.send(`
        <h1>2FA Bypass Lab</h1>
        <p>This lab simulates a 2FA bypass challenge.</p>
        <p><strong>Client</strong>: client / clientpass</p>
        <p><strong>Victim</strong>: victim / victimpass</p>
        <p><a href="/login">Login</a></p>
    `);
});

// Login
app.get('/login', (req, res) => {
    res.send(`
        <h2>Login</h2>
        <form method="post" action="/login">
            <input name="username" placeholder="Username" required><br>
            <input name="password" type="password" placeholder="Password" required><br>
            <button type="submit">Login</button>
        </form>
    `);
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (!users[username] || users[username].password !== password) {
        return res.send('<p>Invalid credentials. <a href="/login">Try again</a></p>');
    }

    // Generate and send 2FA code
    const code = generateCode();
    users[username].secret2FA = code;
    req.session.username = username;
    req.session.authenticated = false;

    if (username === 'client') {
        const email = users[username].email;
        inbox[email] = []; // clear previous emails
        inbox[email].push({
            subject: 'Your 2FA Code',
            body: `Your 2FA code is: ${code}`
        });
    }

    return res.redirect('/2fa');
});

// 2FA Verification Page
app.get('/2fa', (req, res) => {
    if (!req.session.username) return res.redirect('/login');
    
    let linkHTML = '';
    if (req.session.username === 'client') {
        linkHTML = `<a href="/email">Access Client Email</a>`;
    }

    res.send(`
        <h2>Two-Factor Authentication</h2>
        <form method="post" action="/verify">
            <input name="code" placeholder="Enter 2FA code" required><br>
            <button type="submit">Verify</button>
        </form>
        <br>
        ${linkHTML}
    `);
});

app.post('/verify', (req, res) => {
    if (!req.session.username) return res.redirect('/login');
    const inputCode = req.body.code;
    const realCode = users[req.session.username].secret2FA;

    if (inputCode === realCode) {
        req.session.authenticated = true;
        return res.redirect('/account');
    }

    res.send('<p>Invalid 2FA code. <a href="/2fa">Try again</a></p>');
});

// Vulnerable account page
app.get('/account', (req, res) => {
    if (!req.session.username) return res.redirect('/login');

    let emailAccessLink = '';
    if (req.session.username === 'client') {
        emailAccessLink = `<a href="/email">Access Client Email</a>`;
    }

    res.send(`
        <h2>Welcome ${req.session.username}</h2>
        <p>Your account is safe.</p>
       
        <form action="/logout" method="get">
            <button type="submit">Logout</button>
        </form>
    `);
});

// View fake inbox (only for client)
app.get('/email', (req, res) => {
    if (!req.session.username || req.session.username !== 'client') {
        return res.send('<p>You are not authorized to view this inbox.</p>');
    }

    const email = users['client'].email;
    const messages = inbox[email] || [];
    let out = `<h2>Inbox for ${email}</h2>`;
    if (messages.length === 0) out += '<p>No emails yet.</p>';
    else {
        messages.forEach((msg, i) => {
            out += `<div style="border:1px solid #ccc; padding:10px; margin:10px">
                <strong>${msg.subject}</strong><br>${msg.body}
            </div>`;
        });
    }

    res.send(out );
});

// Victim's inbox
app.get('/victim-email', (req, res) => {
    if (!req.session.username || req.session.username !== 'victim') {
        return res.send('<p>You are not authorized to view this inbox.</p>');
    }

    res.send(`
        <h2>Inbox for Victim</h2>
        <p>Access to the victim's email inbox is restricted.</p>
        <form action="/account" method="get">
            <button type="submit">Go back to account</button>
        </form>
    `);
});

// Logout
app.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/'));
});

// Start
app.listen(PORT, () => {
    console.log(`✅ Lab running at http://localhost:${PORT}`);
});
