const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: 'mysecretkey123',
  resave: false,
  saveUninitialized: true,
}));

let users = [
  { id: 1, email: 'client@example.com', password: '123', roleId: 1 },
  { id: 2, email: 'user3@example.com', password: '123', roleId: 1 },
  { id: 3, email: 'admin@example.com', password: 'admin', roleId: 2 }
];

// Render login page
app.get('/', (req, res) => {
  const user = req.session.user;
  if (!user) return res.send(renderLoginPage());
  return res.redirect('/account');
});

// Login
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);
  if (user) {
    req.session.user = user;
    return res.redirect('/account');
  }
  res.send(renderLoginPage('Invalid credentials'));
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

// Account page
app.get('/account', (req, res) => {
  const user = req.session.user;
  if (!user) return res.redirect('/');
  res.send(renderAccountPage(user));
});

// Update account (vulnerable roleId change)
app.post('/account/update', (req, res) => {
  const sessionUser = req.session.user;
  if (!sessionUser) return res.status(401).send('Unauthorized');

  const user = users.find(u => u.id === sessionUser.id);
  const { email, roleId } = req.body;
  if (email) user.email = email;
  if (roleId) user.roleId = parseInt(roleId); // VULNERABILITY

  req.session.user = user;

  res.json({
    message: 'Update successful',
    email: user.email,
    roleId: user.roleId
  });
});

// Admin dashboard
app.get('/admin', (req, res) => {
  const user = req.session.user;
  if (!user || user.roleId !== 2) return res.status(403).send('Access denied');

  const visibleUsers = users.filter(u => u.id !== 3);
  res.send(renderAdminPage(user, visibleUsers));
});

// Admin delete user
app.post('/admin/delete/:id', (req, res) => {
  const user = req.session.user;
  if (!user || user.roleId !== 2) return res.status(403).send('Access denied');

  const targetId = parseInt(req.params.id);
  const target = users.find(u => u.id === targetId);
  if (target && target.id === 3) {
    return res.send('You cannot delete the admin!');
  }

  users = users.filter(u => u.id !== targetId);
  res.redirect('/admin');
});

// ---------- Render Functions ----------

function renderLoginPage(error = '') {
  return `
  <html>
    <head>
      <title>Login</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="container p-5">
      <h2>Login</h2>
      ${error ? `<div class="alert alert-danger">${error}</div>` : ''}
      <form method="POST" action="/login">
        <div class="mb-3"><input class="form-control" type="email" name="email" placeholder="Email" required /></div>
        <div class="mb-3"><input class="form-control" type="password" name="password" placeholder="Password" required /></div>
        <button class="btn btn-primary">Login</button>
      </form>
    </body>
  </html>`;
}

function renderAccountPage(user) {
  return `
  <html>
    <head>
      <title>Account</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="container p-5">
      <h2>Welcome, ${user.email}</h2>
      <form id="updateForm">
        <div class="mb-3"><input class="form-control" type="email" name="email" value="${user.email}" required /></div>
        <button class="btn btn-success">Update</button>
        <a class="btn btn-secondary ms-2" href="/logout">Logout</a>
        ${user.roleId === 2 ? '<a class="btn btn-warning ms-2" href="/admin">Admin Dashboard</a>' : ''}
      </form>
      <div id="updateResult"></div>

      <script>
        document.getElementById('updateForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const email = e.target.email.value;
          const response = await fetch('/account/update', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email }) // You can add "roleId": 2 here using Burp Suite
          });
          const result = await response.json();
          document.getElementById('updateResult').innerHTML = 
            '<div class="alert alert-info mt-3">Updated email: ' + result.email + '</div>';
        });
      </script>
    </body>
  </html>`;
}

function renderAdminPage(user, userList) {
  return `
  <html>
    <head>
      <title>Admin Panel</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="container p-5">
      <h2>Admin Dashboard - ${user.email}</h2>
      <a href="/logout" class="btn btn-secondary mb-3">Logout</a>
      <table class="table table-bordered">
        <thead><tr><th>ID</th><th>Email</th><th>Action</th></tr></thead>
        <tbody>
          ${userList.map(u => `
            <tr>
              <td>${u.id}</td>
              <td>${u.email}</td>
              <td>
                <form method="POST" action="/admin/delete/${u.id}" onsubmit="return confirm('Are you sure?')">
                  <button class="btn btn-danger btn-sm">Delete</button>
                </form>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </body>
  </html>`;
}

app.listen(PORT, () => console.log(`🚀 Server ready at http://localhost:${PORT}`));
